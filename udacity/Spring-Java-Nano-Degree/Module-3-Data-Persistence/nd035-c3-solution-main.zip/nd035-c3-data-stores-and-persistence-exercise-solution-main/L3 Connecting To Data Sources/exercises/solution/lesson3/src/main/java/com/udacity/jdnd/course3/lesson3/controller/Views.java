package com.udacity.jdnd.course3.lesson3.controller;

public class Views {
     public interface Public {}
}
