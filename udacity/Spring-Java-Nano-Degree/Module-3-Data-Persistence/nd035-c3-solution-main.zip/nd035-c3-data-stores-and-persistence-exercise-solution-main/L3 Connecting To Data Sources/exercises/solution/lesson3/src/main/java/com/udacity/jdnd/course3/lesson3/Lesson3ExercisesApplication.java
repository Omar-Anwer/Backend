package com.udacity.jdnd.course3.lesson3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson3ExercisesApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lesson3ExercisesApplication.class, args);
	}

}
