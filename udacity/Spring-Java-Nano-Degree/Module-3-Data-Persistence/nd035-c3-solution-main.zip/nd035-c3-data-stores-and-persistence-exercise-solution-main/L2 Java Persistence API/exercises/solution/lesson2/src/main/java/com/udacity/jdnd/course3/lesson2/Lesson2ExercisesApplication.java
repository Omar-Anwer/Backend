package com.udacity.jdnd.course3.lesson2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson2ExercisesApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lesson2ExercisesApplication.class, args);
	}

}
