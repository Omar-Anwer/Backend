package com.udacity.jdnd.course3.lesson2.controller;

public class Views {
     public interface Public {}
}
