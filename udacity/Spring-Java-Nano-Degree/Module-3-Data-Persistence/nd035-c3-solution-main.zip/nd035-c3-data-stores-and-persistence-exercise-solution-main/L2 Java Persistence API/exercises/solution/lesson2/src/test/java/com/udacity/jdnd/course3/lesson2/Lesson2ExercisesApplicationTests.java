package com.udacity.jdnd.course3.lesson2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lesson2ExercisesApplicationTests {

	@Test
	void contextLoads() {
	}

}
