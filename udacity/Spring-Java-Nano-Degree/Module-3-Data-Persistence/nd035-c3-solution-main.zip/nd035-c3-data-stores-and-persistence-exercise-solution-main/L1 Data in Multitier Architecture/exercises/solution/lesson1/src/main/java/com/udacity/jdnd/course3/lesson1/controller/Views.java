package com.udacity.jdnd.course3.lesson1.controller;

public class Views {
     public interface Public {}
}
