package com.udacity.jdnd.course3.lesson1.data;

import javax.persistence.Entity;

@Entity
public class Flower extends Plant {
    private String color;
    /* getters and setters*/
}
