package com.udacity.jdnd.course3.exercise1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
class Exercise1ApplicationTests {


	@Test
	void contextLoads() {
	}

}
