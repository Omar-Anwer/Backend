package com.udacity.jdnd.course3.lesson4.controller;

public class Views {
     public interface Public {}
}
