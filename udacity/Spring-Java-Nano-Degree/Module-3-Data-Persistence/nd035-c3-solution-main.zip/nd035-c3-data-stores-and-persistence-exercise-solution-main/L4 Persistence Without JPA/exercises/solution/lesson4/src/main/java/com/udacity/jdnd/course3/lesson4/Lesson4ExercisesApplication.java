package com.udacity.jdnd.course3.lesson4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson4ExercisesApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lesson4ExercisesApplication.class, args);
	}

}
