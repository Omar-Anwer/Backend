package com.example.demo.controllers;

import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Before;
import org.junit.Test;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.example.demo.TestUtils;
import static com.example.demo.TestUtils.USER_PASSWORD;
import static com.example.demo.TestUtils.USER_USERNAME;
import static com.example.demo.TestUtils.getUser;
import com.example.demo.model.persistence.User;
import com.example.demo.model.persistence.repositories.CartRepository;
import com.example.demo.model.persistence.repositories.UserRepository;
import com.example.demo.model.requests.CreateUserRequest;


public class UserControllerTest {

    private UserController userController;
    private UserRepository userRepository = mock(UserRepository.class);
    private CartRepository cartRepository = mock(CartRepository.class);
    private BCryptPasswordEncoder bCryptPasswordEncoder = mock(BCryptPasswordEncoder.class);

    @Before
    public void setUp(){
        userController = new UserController();
        TestUtils.injectObjects(userController, "userRepository", userRepository);
        TestUtils.injectObjects(userController, "cartRepository", cartRepository);
        TestUtils.injectObjects(userController, "bCryptPasswordEncoder", bCryptPasswordEncoder);

        User user = getUser();
        when(bCryptPasswordEncoder.encode(anyString())).thenReturn(user.getPassword());
    }

    @Test
    public void testCreateUserHappyPath() throws Exception {
        final CreateUserRequest request = new CreateUserRequest();

        User user = getUser();
        when(userRepository.findByUsername(anyString())).thenReturn(user);

        request.setUsername(USER_USERNAME);
        request.setPassword(USER_PASSWORD);
        request.setConfirmPassword(USER_PASSWORD);

        final ResponseEntity<User> response = userController.createUser(request);
        assertNotNull(response);
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
        
        User createdUser = response.getBody();
        assertNotNull(createdUser);
        assertEquals(USER_USERNAME, createdUser.getUsername());
        assertEquals(USER_PASSWORD, createdUser.getPassword());
    }

    @Test
    public void testVerifyShortPassword() throws Exception {
        final CreateUserRequest request = new CreateUserRequest();
        request.setUsername(USER_USERNAME);
        request.setPassword("short");
        request.setConfirmPassword("short");

        final ResponseEntity<User> response = userController.createUser(request);
        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCodeValue());
    }

    @Test
    public void testVerifyUnmatchedPassword() throws Exception {
        final CreateUserRequest request = new CreateUserRequest();
        request.setUsername(USER_USERNAME);
        request.setPassword(USER_PASSWORD);
        request.setConfirmPassword("unmatched");

        final ResponseEntity<User> response = userController.createUser(request);
        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatusCodeValue());
    }

    @Test
    public void testVerifyValidUserId() throws Exception {
        User user = getUser();
        when(userRepository.findById(anyLong())).thenReturn(Optional.of(user));

        final ResponseEntity<User> response = userController.findById(user.getId());
        assertNotNull(response);
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
        User createdUser = response.getBody();
        assertNotNull(createdUser);
        assertEquals(user.getId(), createdUser.getId());
    }

    @Test
    public void testVerifyValidUserName() throws Exception {
        User user = getUser();
        when(userRepository.findByUsername(anyString())).thenReturn(user);

        final ResponseEntity<User> response = userController.findByUserName(user.getUsername());
        assertNotNull(response);
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
        User createdUser = response.getBody();
        assertNotNull(createdUser);
        assertEquals(user.getUsername(), createdUser.getUsername());
    }

    @Test
    public void testVerifyInvalidUserName() {
        User user = new User();
        user.setUsername(USER_USERNAME);
        when(userRepository.findByUsername(USER_USERNAME)).thenReturn(user);

        ResponseEntity<User> response = userController.findByUserName("");
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatusCodeValue());
    }
}
