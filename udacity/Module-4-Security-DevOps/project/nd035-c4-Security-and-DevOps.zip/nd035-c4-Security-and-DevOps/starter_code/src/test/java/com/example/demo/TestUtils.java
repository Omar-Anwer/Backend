package com.example.demo;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.model.persistence.Cart;
import com.example.demo.model.persistence.Item;
import com.example.demo.model.persistence.User;
import com.example.demo.model.persistence.UserOrder;

public class TestUtils {
    public static void injectObjects(Object target, String fieldName, Object toInject) {
        
        boolean wasPrivate = false;

        try {
            Field f = target.getClass().getDeclaredField(fieldName);
            if (!f.isAccessible()) {
                f.setAccessible(true);
                wasPrivate = true;
            }
            
            f.set(target, toInject);

            if (wasPrivate) {
                f.setAccessible(false);
            }
        } catch (NoSuchFieldException | IllegalArgumentException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }


    public static final String USER_USERNAME = "test";
    public static final String USER_PASSWORD = "somepassword";

    public static final String ITEM_NAME = "Round Widget";
    public static final double ITEM_PRICE = 43.28;
    public static final String ITEM_DESCRIPTION = "A widget that is round";


    public static User getUser() {
        User user = new User();
        long id = 1L;
		user.setId(id);
        user.setUsername(USER_USERNAME);
        user.setPassword(USER_PASSWORD);
		Cart cart = new Cart();
        user.setCart(cart);
		return user;
	}

    public static Item getItem(){
        Item item = new Item();
        long id = 1L;
        item.setId(id);
        item.setName(ITEM_NAME);
        item.setPrice(BigDecimal.valueOf(ITEM_PRICE));
        item.setDescription(ITEM_DESCRIPTION);
        return item;
    }

    public static Cart getCart() {
        Cart cart = new Cart();
        long id = 1L;
        cart.setId(id);
        cart.setUser(getUser());
        cart.setItems(new ArrayList<>());
        //cart.addItem(getItem());
        //cart.setTotal(cart.getItems().stream().map(item -> item.getPrice()).reduce(BigDecimal::add).get());
        return cart;
    }

    public static UserOrder getOrder(){
        UserOrder order = new UserOrder();
        long id = 1;
        order.setId(id);
        return order;
    }

}
