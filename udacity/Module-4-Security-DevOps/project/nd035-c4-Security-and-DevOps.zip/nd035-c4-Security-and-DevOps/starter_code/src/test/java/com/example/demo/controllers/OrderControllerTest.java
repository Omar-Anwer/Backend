package com.example.demo.controllers;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Before;
import org.junit.Test;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.demo.TestUtils;
import static com.example.demo.TestUtils.getCart;
import static com.example.demo.TestUtils.getOrder;
import static com.example.demo.TestUtils.getUser;
import com.example.demo.model.persistence.Cart;
import com.example.demo.model.persistence.User;
import com.example.demo.model.persistence.UserOrder;
import com.example.demo.model.persistence.repositories.ItemRepository;
import com.example.demo.model.persistence.repositories.OrderRepository;
import com.example.demo.model.persistence.repositories.UserRepository;


public class OrderControllerTest {

    private OrderController orderController;
    private OrderRepository orderRepository = mock(OrderRepository.class);
    private ItemRepository itemRepository = mock(ItemRepository.class);
    private UserRepository userRepository = mock(UserRepository.class);

    @Before
    public void setUp(){
        orderController = new OrderController();
        TestUtils.injectObjects(orderController, "orderRepository", orderRepository);
        TestUtils.injectObjects(orderController, "userRepository", userRepository);


        User user = getUser();
        Cart cart = getCart();
        cart.setUser(user);
        user.setCart(cart);

        UserOrder order = getOrder();
        order.setUser(user);
        order.setItems(cart.getItems());

        when(userRepository.findByUsername(anyString())).thenReturn(user);
    }

    @Test
    public void testVerifySubmitOrder(){
        User user = getUser();
        UserOrder order = getOrder();
        ResponseEntity<UserOrder> response = orderController.submit(user.getUsername());
        assertNotNull(response);
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
        UserOrder userOrder = response.getBody();
        assertNotNull(userOrder);

        assertEquals(user.getUsername(), userOrder.getUser().getUsername());
    }

    @Test
    public void testVerifyUserHistory(){
        User user = getUser();
        ResponseEntity<List<UserOrder>> response = orderController.getOrdersForUser(user.getUsername());
        assertNotNull(response);
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
        List<UserOrder> userOrders = response.getBody();
        assertNotNull(userOrders);    
    }
}
