package com.example.demo.controllers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.demo.TestUtils;

import static com.example.demo.TestUtils.ITEM_DESCRIPTION;
import static com.example.demo.TestUtils.ITEM_NAME;
import static com.example.demo.TestUtils.ITEM_PRICE;
import static com.example.demo.TestUtils.USER_PASSWORD;
import static com.example.demo.TestUtils.USER_USERNAME;
import static com.example.demo.TestUtils.getCart;
import static com.example.demo.TestUtils.getItem;
import static com.example.demo.TestUtils.getUser;
import com.example.demo.model.persistence.Cart;
import com.example.demo.model.persistence.Item;
import com.example.demo.model.persistence.User;
import com.example.demo.model.persistence.repositories.CartRepository;
import com.example.demo.model.persistence.repositories.ItemRepository;
import com.example.demo.model.persistence.repositories.UserRepository;
import com.example.demo.model.requests.ModifyCartRequest;

public class CartControllerTest {
    private CartController cartController;
    private UserRepository userRepository = mock(UserRepository.class);
    private CartRepository cartRepository = mock(CartRepository.class);
    private ItemRepository itemRepository = mock(ItemRepository.class);

    @Before
    public void setUp(){
        cartController = new CartController();
        TestUtils.injectObjects(cartController, "userRepository", userRepository);
        TestUtils.injectObjects(cartController, "cartRepository", cartRepository);
        TestUtils.injectObjects(cartController, "itemRepository", itemRepository);

        Cart cart = getCart();
        User user = getUser();
        Item item = getItem();
        user.setCart(cart);
        cart.setUser(user);
        when(userRepository.findByUsername(anyString())).thenReturn(user);
        when(itemRepository.findById(anyLong())).thenReturn(Optional.of(item));
    }

    @Test
    public void testVerifyAddToCart(){
        Cart cart = getCart();
        Item item = getItem();
        User user = getUser();
        user.setCart(cart);
        cart.setUser(user);

        ModifyCartRequest request = new ModifyCartRequest();
        request.setItemId(1);
        request.setQuantity(1);
        request.setUsername(user.getUsername());

        final ResponseEntity<Cart> response = cartController.addTocart(request);
        assertNotNull(response);
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());

        Cart createdCart = response.getBody();
        assertNotNull(createdCart);
      
        assertEquals(user.getUsername(), createdCart.getUser().getUsername());
        // assertEquals(cart.getId(), createdCart.getId());
        //assertEquals(cart.getItems().size() , createdCart.getItems().size() + request.getQuantity());

        //cart.addItem(getItem());
        //cart.setTotal(cart.getItems().stream().map(item -> item.getPrice()).reduce(BigDecimal::add).get());

        //BigDecimal expectedTotal = item.getPrice().multiply(BigDecimal.valueOf(request.getQuantity())).add(createdCart.getTotal());
        //BigDecimal actualTotal = item.getPrice().multiply(BigDecimal.valueOf(request.getQuantity())).add(cart.getTotal());

        //assertEquals(actualTotal, expectedTotal);

        //        assertEquals(generatedCart.getItems().size() + request.getQuantity(), actualCart.getItems().size());


        // assertEquals(item, createdCart.getItems().get(0));
        //assertEquals(cart.getId(), createdCart.getId());        

    }

    @Test
    public void testVerifyRemoveFromCart(){
        Cart cart = getCart();
        User user = getUser();
        user.setCart(cart);
        cart.setUser(user);

        ModifyCartRequest request = new ModifyCartRequest();
        request.setItemId(1);
        request.setQuantity(1);
        request.setUsername(user.getUsername());

        final ResponseEntity<Cart> response = cartController.removeFromcart(request);
        assertNotNull(response);
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
    }

}
