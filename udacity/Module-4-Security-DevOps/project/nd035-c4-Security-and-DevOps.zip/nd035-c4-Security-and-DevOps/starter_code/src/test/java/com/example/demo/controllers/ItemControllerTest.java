package com.example.demo.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Before;
import org.junit.Test;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.demo.TestUtils;
import static com.example.demo.TestUtils.getItem;
import com.example.demo.model.persistence.Item;
import com.example.demo.model.persistence.repositories.ItemRepository;

public class ItemControllerTest {
    private ItemController itemController;
    private ItemRepository itemRepository = mock(ItemRepository.class);

    @Before
    public void setUp(){
        itemController = new ItemController();
        TestUtils.injectObjects(itemController, "itemRepository", itemRepository);        
    }

    @Test
    public void testVerifyValidItem(){
        Item item = getItem();
        when(itemRepository.findById(anyLong())).thenReturn(Optional.of(item));

        ResponseEntity<Item> response = itemController.getItemById(item.getId());
        assertNotNull(response);
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
        Item createdItem = response.getBody();
        assertNotNull(createdItem);

        assertEquals(true, item.equals(createdItem));

        assertEquals(item, createdItem);
        assertEquals(item.getName(), createdItem.getName());
        assertEquals(item.getId(), createdItem.getId());
        assertEquals(item.getDescription(), createdItem.getDescription());
    }

    @Test
    public void testVerifyValidItemName(){
        Item item = getItem();
        List<Item> listOfItems = new ArrayList<>();
        listOfItems.add(item);
        when(itemRepository.findByName(anyString())).thenReturn(listOfItems);

        ResponseEntity<List<Item>> responseEntity = itemController.getItemsByName(item.getName());
        List<Item> items = responseEntity.getBody();

        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
        assertNotNull(items);
        assertEquals(1, items.size());
    }

    @Test
    public void testVerifyInvalidItemName(){
        ResponseEntity<List<Item>> responseEntity = itemController.getItemsByName("");
        assertEquals(HttpStatus.NOT_FOUND.value(), responseEntity.getStatusCodeValue());
    }

    @Test
    public void testFindAll(){
        Item item = getItem();
        List<Item> listOfItems = new ArrayList<>();
        listOfItems.add(item);
        when(itemRepository.findAll()).thenReturn(listOfItems);
        ResponseEntity<List<Item>> responseEntity = itemController.getItems();
        List<Item> items = responseEntity.getBody();

        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
        assertNotNull(items);
        assertEquals(1, items.size());
    }

}
